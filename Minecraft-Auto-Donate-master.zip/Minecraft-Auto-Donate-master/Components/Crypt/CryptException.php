<?php

class CryptException extends \Exception {}

?>