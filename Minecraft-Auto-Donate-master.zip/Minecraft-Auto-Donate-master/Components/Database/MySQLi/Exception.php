<?php

class MySQLiDBException extends \Exception {}

?>