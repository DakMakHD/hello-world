<?php

class DatabaseException extends \Exception {}

?>