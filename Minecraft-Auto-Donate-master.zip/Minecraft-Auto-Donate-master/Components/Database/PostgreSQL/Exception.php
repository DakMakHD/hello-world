<?php

class PostgreSQLDBException extends \Exception {}

?>